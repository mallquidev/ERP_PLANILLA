from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
import pyodbc
from database import get_connection
from security import get_current_user

router = APIRouter(prefix="/empresa", tags=["Empresa"])

class Empresa(BaseModel):
    IDEmpresa: int
    RazonSocial: str
    NumeroRuc: str
    PKIDRegimenTributario: int
    PKIDSituacionRegistro: int
    PKIDSectorEconomico: int
    Direccion: str
    RegistroPatronal: str | None = None
    PKIDOtraEmpresa: int | None = None
    Siglas: str | None = None

# Obtener todas las empresas con nombres descriptivos
@router.get("/")
def listar_empresas(user: dict = Depends(get_current_user)):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT e.IDEmpresa, e.RazonSocial, e.NumeroRuc,
                   e.PKIDRegimenTributario, r.RegimenTributario,
                   e.PKIDSituacionRegistro, s.SituacionRegistro,
                   e.PKIDSectorEconomico, se.SectorEconomico,
                   e.Direccion, e.RegistroPatronal, e.PKIDOtraEmpresa, e.Siglas
            FROM Empresa e
            JOIN RegimenTributario r ON e.PKIDRegimenTributario = r.PKID
            JOIN SituacionRegistro s ON e.PKIDSituacionRegistro = s.PKID
            JOIN SectorEconomico se ON e.PKIDSectorEconomico = se.PKID
            ORDER BY e.IDEmpresa
        """)

        columns = [col[0] for col in cursor.description]
        results = [dict(zip(columns, row)) for row in cursor.fetchall()]

        conn.close()
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Crear empresa
@router.post("/")
def crear_empresa(data: Empresa, user: dict = Depends(get_current_user)):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO Empresa (
                IDEmpresa, RazonSocial, NumeroRuc,
                PKIDRegimenTributario, PKIDSituacionRegistro, PKIDSectorEconomico,
                Direccion, RegistroPatronal, PKIDOtraEmpresa, Siglas
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.IDEmpresa, data.RazonSocial, data.NumeroRuc,
            data.PKIDRegimenTributario, data.PKIDSituacionRegistro, data.PKIDSectorEconomico,
            data.Direccion, data.RegistroPatronal, data.PKIDOtraEmpresa, data.Siglas
        ))
        conn.commit()
        conn.close()
        return {"message": "Empresa creada correctamente"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Actualizar empresa
@router.put("/{id}")
def actualizar_empresa(id: int, data: Empresa, user: dict = Depends(get_current_user)):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE Empresa
            SET RazonSocial=?, NumeroRuc=?, PKIDRegimenTributario=?,
                PKIDSituacionRegistro=?, PKIDSectorEconomico=?,
                Direccion=?, RegistroPatronal=?, PKIDOtraEmpresa=?, Siglas=?
            WHERE IDEmpresa=?
        """, (
            data.RazonSocial, data.NumeroRuc, data.PKIDRegimenTributario,
            data.PKIDSituacionRegistro, data.PKIDSectorEconomico,
            data.Direccion, data.RegistroPatronal, data.PKIDOtraEmpresa, data.Siglas,
            id
        ))
        conn.commit()
        conn.close()
        return {"message": "Empresa actualizada correctamente"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Eliminar empresa
@router.delete("/{id}")
def eliminar_empresa(id: int, user: dict = Depends(get_current_user)):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM Empresa WHERE IDEmpresa=?", id)
        conn.commit()
        conn.close()
        return {"message": "Empresa eliminada correctamente"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
