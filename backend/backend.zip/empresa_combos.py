from fastapi import APIRouter, HTTPException, Depends
from database import get_connection
from security import get_current_user

router = APIRouter(prefix="/empresa-combos", tags=["Empresa Combos"])

def _rows(query: str):
    conn = get_connection(); cur = conn.cursor()
    cur.execute(query)
    data = [{"id": r[0], "nombre": r[1]} for r in cur.fetchall()]
    cur.close(); conn.close()
    return data

# --- Regimen Tributario ---
@router.get("/regimen")  # rutas cortas
@router.get("/regimen_tributario")  # rutas con underscore
def listar_regimen(user: dict = Depends(get_current_user)):
    try:
        return _rows("SELECT PKID, RegimenTributario FROM RegimenTributario ORDER BY RegimenTributario")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- Situacion Registro ---
@router.get("/situacion")
@router.get("/situacion_registro")
def listar_situacion(user: dict = Depends(get_current_user)):
    try:
        return _rows("SELECT PKID, SituacionRegistro FROM SituacionRegistro ORDER BY SituacionRegistro")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- Sector Economico ---
@router.get("/sector")
@router.get("/sector_economico")
def listar_sector(user: dict = Depends(get_current_user)):
    try:
        return _rows("SELECT PKID, SectorEconomico FROM SectorEconomico ORDER BY SectorEconomico")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
